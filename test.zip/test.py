print("Hello, Python")
